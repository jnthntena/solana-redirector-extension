# solana-redirector-extension
Simple tool to help you redirect to your preferred chain/platform.
